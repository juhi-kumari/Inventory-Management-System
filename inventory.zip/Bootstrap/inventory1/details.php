<?php
	include ('include/connect.php');
	$error=0;
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		
		$id = $_POST['id'];
	//	echo $id;
		$table = $_POST['type'];
		$name = $_POST['name'];
		$address = $_POST['address'];
		$contact = $_POST['contact'];
		$email = $_POST['email'];
		$city = $_POST['city'];
		$state = $_POST['state'];
		$pincode = $_POST['pincode'];
		
		
		if($table == "customer"){
			$query = "UPDATE {$table} SET Cust_name = '{$name}', Contact = '{$contact}', Email_id = '{$email}', Address = '{$address}', Pincode = '{$pincode}' WHERE Cust_id = $id";
			//echo $query;
			$result = mysqli_query($con, $query) or die ("Update later!");
			if($result){
				echo "updated successfully";
			}else{
				die ("Update later!");
				$error=1;
			}
			//$query = "UPDATE ". $table . " SET id = '{$id}', foreign_id = '{$id_new}' ,
		}else if($table == "admin"){
			$query = "UPDATE {$table} SET Admin_name = '{$name}', Contact = '{$contact}', Email_id = '{$email}', Address = '{$address}', Pincode = '{$pincode}' WHERE Admin_id = $id";
			//echo $query;
			$result = mysqli_query($con, $query) or die ("Update later!");
			if($result){
				echo "updated successfully";
			}else{
				die ("Update later!");
				$error=1;
			}
		}else if($table = "dealer"){
			$query = "UPDATE {$table} SET Dealer_name = '{$name}', Contact = '{$contact}', Email_id = '{$email}', Address = '{$address}', Pincode = '{$pincode}' WHERE Dealer_id = $id";
			echo $query;
			$result = mysqli_query($con, $query) or die ("Update later!");
			if($result){
				echo "updated successfully";
			}else{
				die ("Update later!");
				$error=1;
			}
		}
		//updation for pincode
		$query = "SELECT count(Pincode) FROM pincodes where Pincode = $pincode";
		//echo $query;
		$result = mysqli_query($con, $query) or die ("Connection Failure");
		$row = mysqli_fetch_row($result);
		
		echo $row[0];
		if($row[0] == 0){
			//INSERT
			//$query = "INSERT INTO {$table1} (username, password, id, type) VALUES ('$user', '$pass', $f, '$type')";
			$q = "INSERT INTO pincodes (Pincode, City, State) VALUES ('$pincode', '$city', '$state')";
			echo $q;
			$result = mysqli_query($con, $q) or die ("Pincode not inserted");
			if($result){
				echo "updated succeddfully";
			}else{
				die ("Update later!");
				$error=1;
			}
		}else{
			echo "pincode already exist";
			//No need to inserted
		}
		if($error == 0){
			header('Location:personal.php?var=1');
			echo "hi";
		}
		
	}else if($error == 0){
		header('Location:personal.php');
		echo "yo:";
	}
?>
