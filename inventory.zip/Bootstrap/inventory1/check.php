<?php
	include ('include/connect.php');
	include ('include/session.php');
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$username = $_POST['name'];
		$pass = $_POST['pass'];
		$table = "verification";
		$mysqli_q = "SELECT count(id), type, id FROM " . $table . " where username = '$username' AND password = '$pass'"; 
		$result = mysqli_query($con, $mysqli_q) or die ("Connection Failure");
		$row = mysqli_fetch_row($result);
		if($row[0] == 0){
			echo "Wrong password or Username";
			header("Location:login.php");
		} else{
			//set session $row['id'], $row['type']
			if ($row[1] == "admin") {
				header("Location:transaction_ac.php");
			} else if ($row[1] == "customer") {
				header("Location:cust_order_hist.php");
			} else if ($row[1] == "dealer") {
				header("Location:supply_hist.php");
			}
			
			$_SESSION['type']=$row[1];
			$_SESSION['id']=$row[2];
			$_SESSION['username']=$username; 

		}
		
		
		
	}
	
?>