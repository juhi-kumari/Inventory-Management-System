<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/nik.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">
    <script src="js/respond.js"></script> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.5.custom.min.js"></script>
</head>

<body>
	<header>
		<nav class = "row">
			<div class = "container">
			<div class= "col-lg-4 col-md-4 col-sm-4 col-xs-4">
				<h1>Inventory Solutions</h1>
			</div> 
			<div class= "col-lg-offset-1 col-lg-7 col-md-offset-0 col-md-8 col-sm-offset-0 col-sm-8  col-xs-offset-3 col-xs-5">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="customer_ac.php">Products</a></li>
					<li><a href="#">Vendors</a></li>
					<li><a href="sign.php">Sign Up</a></li>
					<li><a href="login.php">Login</a></li>
				</ul>
			</div>
			</div> 
		</nav>
		<section class= "adv-content col-lg-12 col-xs-12">
			<div class = "container">
			<ul class="breadcrumb">
				<li class="active"><a href="index.html">HOME</a></li>
			</ul>
		</div>
		</section>
	</header>
	<section id="content">
		  <div class="top">
		    <div class="container">
		      <div class="clearfix row">
		        <section id="gallery" class="col-lg-6 col-md-6">
			      <div class="pics"> <img src="images/slide1.jpg" alt="" width="495" height="329"> <img src="images/slide3.jpg" alt="" width="495" height="329"> <img src="images/slide2.jpg" alt="" width="495" height="329"> <img src="images/slide4.jpg" alt="" width="495" height="329"> <img src="images/slide5.jpg" alt="" width="495" height="329"> 
		          </div>
		          <a href="#" id="prev"></a> <a href="#" id="next"></a>
				</section>
		        <section id="intro" class="col-lg-5 col-lg-offset-1 col-md-5 col-md-offset-1">
		            <div class="inner">
						<h2>Top<br/>
						  Selling<span>Products</span></h2>
						<p>Best place to buy electronic goods..<br />
						  We keep and sell electronics goods like air conditioners, televisions, refrigerators, laptops of various companies like Samsung, Onida, LG, Godrej, Videocon any many more.
						</p>
						<a href="#" class="extra-button">Read More</a> 
				    </div>
		        </section>
		      </div>
		    </div>
		  </div>
			 <div class="middle">
			    <div class="container">
			      <div class="wrapper row">
			        <div class="col-lg-3 col-md-3 col-sm-4">
			          <ul class="categories">
			            <li><a href="#">About Us</a></li>
			            <li><a href="#">Products</a></li>
			            <li><a href="#">Top selling</a></li>
			            <li><a href="#">Offers</a></li>
			            <li><a href="#">Vendors Corner</a></li>
			            <li><a href="#">Customers Corner</a></li>
			            
			            <li><a href="#">Contact</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-9 col-md-9 col-sm-8">
			          <h2>Grow service revenue with world-class<br />
			            lifecycle service and support.</h2>
			          <p>Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Pellentesque sed dolor. Aliquam congue fermentum nisl. Mauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede m aliquet sit amet, euismod in, auctor ut, ligula. Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis, lobortisissim, pulvinar ac, lorem. Vestibulum sed ante. Donec sagittis euismod purus.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta. </p>
			          <p><a href="#" class="more">Read More</a></p>
			          <section class="images">
			            <figure><a href="#"><img src="images/1page-img1.jpg" alt=""></a></figure>
			            <figure><a href="#"><img src="images/1page-img2.jpg" alt=""></a></figure>
			            <figure><a href="#"><img src="images/1page-img3.jpg" alt=""></a></figure>
			          </section>
			        </div>
			      </div>
			    </div>
			  </div>
			    <div class="bottom">
			    <div class="container">
			      <div class="wrapper row">
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Database</h3>
			          <ul class="list1">
			            <li><a href="#">Real Application Clusters</a></li>
			            <li><a href="#">Database Security</a></li>
			            <li><a href="#">Secure Enterprise Search</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Quick Links</h3>
			          <ul class="list2">
			            <li><a href="#">Vendors</a></li>
			            <li><a href="#">Login</a></li>
			            <li><a href="#"></a></li>
			            <li><a href="#">For Midsize Companies</a></li>
			            <li><a href="#">Investors</a></li>
			            <li><a href="#">Technology Network</a></li>
			            <li><a href="#">FAQs</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Top Selling</h3>
			          <ul class="list2">
			            <li><a href="#">Enterprise Architecture</a></li>
			            <li><a href="#">Enterprise 2.0</a></li>
			            <li><a href="#">Grid</a></li>
			            <li><a href="#">Service-Oriented Architecture</a></li>
			            <li><a href="#">Virtualization</a></li>
			            <li><a href="#">Database XE</a></li>
			            <li><a href="#">Enterprise Management</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <div id="datepicker"></div>
			        </div>
			      </div>
			    </div>
			  </div>

	</section>

	<footer>
  <div class="footerlink">
  	 <div class="container">
    <p class="lf">Copyright &copy;  <a href="#"></a> - All Rights Reserved</p>
    <div style="clear:both;"></div>
</div>
  </div>
</footer>


<script type="text/javascript">
$(document).ready(function () {
    $('.pics').cycle({
        fx: 'toss',
        next: '#next',
        prev: '#prev'
    });
    $('#datepicker').datepicker({
        inline: true
    });
});
</script>

</body>
</html>
