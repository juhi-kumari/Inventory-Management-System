<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/nik.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">
    <script src="js/respond.js"></script> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.5.custom.min.js"></script>
</head>

<body>
	<header>
		<nav class = "row">
			<div class = "container">
			<div class= "col-lg-4 col-md-4 col-sm-4 col-xs-4">
				<h1>Inventory Solutions</h1>
			</div> 
			<div class= "col-lg-offset-1 col-lg-7 col-md-offset-0 col-md-8 col-sm-offset-0 col-sm-8  col-xs-offset-3 col-xs-5">
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Products</a></li>
					<li><a href="#">Vendors</a></li>
					<li><a href="#">Contact Us</a></li>
					<li><a href="#">Login</a></li>
				</ul>
			</div>
			</div> 
		</nav>
		<section class= "adv-content col-lg-12 col-xs-12">
			<div class = "container">
			<ul class="breadcrumb">
				<li><a href="index.html">HOME</a></li>
				<li class="active"><a href="customer_ac.php">A.C.</a></li>
			</ul>
		</div>
		</section>
	</header>
	<section id="content">
			 <div class="middle">
			    <div class="container">
				<div class="col-lg-12 col-md-12 col-sm-12">
				<ul class="nav nav-tabs">
							  <li role="presentation" class="active"><a href="#">AC</a></li>
							  <li role="presentation" ><a href="customer_fr.php">REFRIGERATOR</a></li>
							  <li role="presentation"><a href="customer_lp.php">LAPTOP</a></li>
							  <li role="presentation"  ><a href="customer_tv.php">TV</a></li>
							</ul>
							<br/> <br/>
				</div>
				
			      <div class="wrapper row">
			        <div class="col-lg-3 col-md-3 col-sm-4">
						<?php include('include/lmenu_ac.php');?>
			        </div>
			        <div class="col-lg-9 col-md-9 col-sm-8">
			                <div class="row carousel-holder">
								<div class="col-md-12">
									<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
										<ol class="carousel-indicators">
											<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
											<li data-target="#carousel-example-generic" data-slide-to="1"></li>
											<li data-target="#carousel-example-generic" data-slide-to="2"></li>
										</ol>
										<div class="carousel-inner">
											<div class="item active">
												<img class="slide-image" src="images/laptops/bck_image.jpg" alt="">
											</div>
											<div class="item">
												<img class="slide-image" src="images/2page-img2.jpg" alt="">
											</div>
											<div class="item">
												<img class="slide-image" src="images/1page-img2.jpg" alt="">
											</div>
										</div>
										<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
											<span class="glyphicon glyphicon-chevron-left"></span>
										</a>
										<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
											<span class="glyphicon glyphicon-chevron-right"></span>
										</a>
									</div>
								</div>
							</div>
							<br/>
							<div class="row">
								<div class="col-sm-4 col-lg-4 col-md-4">
									<div class="thumbnail">
										<img src="http://placehold.it/320x150" alt="">
										<div class="caption">
											<h4 class="pull-right">$24.99</h4>
											<h4><a href="#">First Product</a>
											</h4>
											<p>See more snippets like this online store item at <a target="_blank" href="http://www.bootsnipp.com">Bootsnipp - http://bootsnipp.com</a>.</p>
										</div>
										<div class="ratings">
											<p class="pull-right">15 reviews</p>
											<p>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
											</p>
										</div>
									</div>
								</div>

								<div class="col-sm-4 col-lg-4 col-md-4">
									<div class="thumbnail">
										<img src="http://placehold.it/320x150" alt="">
										<div class="caption">
											<h4 class="pull-right">$64.99</h4>
											<h4><a href="#">Second Product</a>
											</h4>
											<p>This is a short description. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div>
										<div class="ratings">
											<p class="pull-right">12 reviews</p>
											<p>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star-empty"></span>
											</p>
										</div>
									</div>
								</div>

								<div class="col-sm-4 col-lg-4 col-md-4">
									<div class="thumbnail">
										<img src="http://placehold.it/320x150" alt="">
										<div class="caption">
											<h4 class="pull-right">$74.99</h4>
											<h4><a href="#">Third Product</a>
											</h4>
											<p>This is a short description. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div>
										<div class="ratings">
											<p class="pull-right">31 reviews</p>
											<p>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star-empty"></span>
											</p>
										</div>
									</div>
								</div>

								<div class="col-sm-4 col-lg-4 col-md-4">
									<div class="thumbnail">
										<img src="http://placehold.it/320x150" alt="">
										<div class="caption">
											<h4 class="pull-right">$84.99</h4>
											<h4><a href="#">Fourth Product</a>
											</h4>
											<p>This is a short description. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div>
										<div class="ratings">
											<p class="pull-right">6 reviews</p>
											<p>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star-empty"></span>
												<span class="glyphicon glyphicon-star-empty"></span>
											</p>
										</div>
									</div>
								</div>

								<div class="col-sm-4 col-lg-4 col-md-4">
									<div class="thumbnail">
										<img src="http://placehold.it/320x150" alt="">
										<div class="caption">
											<h4 class="pull-right">$94.99</h4>
											<h4><a href="#">Fifth Product</a>
											</h4>
											<p>This is a short description. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
										</div>
										<div class="ratings">
											<p class="pull-right">18 reviews</p>
											<p>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star-empty"></span>
											</p>
										</div>
									</div>
								</div>

								<div class="col-sm-4 col-lg-4 col-md-4">
									<h4><a href="#">Like this template?</a>
									</h4>
									<p>If you like this template, then check out <a target="_blank" href="http://maxoffsky.com/code-blog/laravel-shop-tutorial-1-building-a-review-system/">this tutorial</a> on how to build a working review system for your online store!</p>
									<a class="btn btn-primary" target="_blank" href="http://maxoffsky.com/code-blog/laravel-shop-tutorial-1-building-a-review-system/">View Tutorial</a>
								</div>
			        </div>
			      </div>
			    </div>
			  </div>
			  </div>
			  
	


<footer>
  <div class="footerlink">
  	 <div class="container">
    <p class="lf">Copyright &copy;  <a href="#"></a> - All Rights Reserved</p>
    <div style="clear:both;"></div>
</div>
  </div>
</footer>


<script type="text/javascript">
$(document).ready(function () {
    $('.pics').cycle({
        fx: 'toss',
        next: '#next',
        prev: '#prev'
    });
    $('#datepicker').datepicker({
        inline: true
    });
});
</script>

</body>
</html>
