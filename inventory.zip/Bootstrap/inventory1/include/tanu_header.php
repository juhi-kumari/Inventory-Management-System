<?php
				echo'<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="customer_ac.php">Products</a></li>
					<li><a href="personald.php">Vendors</a></li>
					<li><a href="contact.php">Contact Us</a></li>
					<li><a href="login.php">Login</a></li>
				</ul>';
		?>