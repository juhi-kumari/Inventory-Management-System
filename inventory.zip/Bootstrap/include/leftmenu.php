			        <?php  
					echo '
					<ul class="heading">
			            <li><a href="#">DAILY REPORT</a></li>
					  </ul>
					  <ul  class="categories">
					    <li><a href="transaction_ac.php">Monetary Transactions</a></li>
					    <li><a href="stats_ac.php">Sales Statistics</a></li>
			          </ul>
					<ul class="heading">
			            <li><a href="#">INVENTORY</a></li>
					  </ul>
					  <ul  class="categories">
			            <li><a href="add_ac.php">Add item</a></li>
			            <li><a href="add_e_ac.php">Modify items</a></li>
			            <li><a href="add_s_ac.php">See shortages</a></li>
			            <li><a href="add_t_ac.php">Top selling</a></li>
			            <li><a href="#">Locate/Track Item</a></li>
					  </ul>
			          <ul class="heading">
			            <li><a href="#">PERSONAL</a></li>
					  </ul>
					  <ul  class="categories">
					    <li><a href="personal.php">Edit Details</a></li>
					    <li><a href="change.php">Change Password</a></li>
			          </ul>';
					  ?>
