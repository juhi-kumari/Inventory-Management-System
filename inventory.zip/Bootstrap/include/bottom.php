	<?php 	echo '
			  <div class="bottom">
			    <div class="container">
			      <div class="wrapper row">
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Database</h3>
			          <ul class="list1">
			            <li><a href="#">Real Application Clusters</a></li>
			            <li><a href="#">Database Security</a></li>
			            <li><a href="#">Secure Enterprise Search</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Quick Links</h3>
			          <ul class="list2">
			            <li><a href="#">Vendors</a></li>
			            <li><a href="#">Login</a></li>
			            <li><a href="#"></a></li>
			            <li><a href="#">For Midsize Companies</a></li>
			            <li><a href="#">Investors</a></li>
			            <li><a href="#">Technology Network</a></li>
			            <li><a href="#">FAQs</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Top Selling</h3>
			          <ul class="list2">
			            <li><a href="#">Enterprise Architecture</a></li>
			            <li><a href="#">Enterprise 2.0</a></li>
			            <li><a href="#">Grid</a></li>
			            <li><a href="#">Service-Oriented Architecture</a></li>
			            <li><a href="#">Virtualization</a></li>
			            <li><a href="#">Database XE</a></li>
			            <li><a href="#">Enterprise Management</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <div id="datepicker"></div>
			        </div>
			      </div>
			    </div>
			  </div>
			  </section>

				<footer>
			  <div class="footerlink">
				 <div class="container">
				<p class="lf">Copyright &copy;  <a href="#"></a> - All Rights Reserved</p>
				<div style="clear:both;"></div>
			</div>
			  </div>
			</footer>
';