			        <?php  
					echo '
					<ul class="heading">
			            <li><a href="#">INVENTORY</a></li>
					  </ul>
					  <ul  class="categories">
					    <li><a href="supply_hist.php">Supply History</a></li>
					    <li><a href="supply.php">Supply</a></li>
						<li><a href="add_item.php">Add Item</a></li>
						<li><a href="delete_item.php">Delete Item</a></li>
			          </ul>
			          <ul class="heading">
			            <li><a href="#">PERSONAL</a></li>
					  </ul>
					  <ul  class="categories">
					    <li><a href="personald.php">Edit Details</a></li>
					    <li><a href="changed.php">Change Password</a></li>
			          </ul>';
					  ?>
