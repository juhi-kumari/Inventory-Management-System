<?php
	$db_host = "localhost";
	$db_usr = "root";
	$db_pass = "";
	//$db_pass = "";
	$db_database = "inventory";
	$con = $db_con = "";
	$name = $id = $passwod = "";
	$table = "";

	$con = mysqli_connect($db_host, $db_usr, $db_pass, $db_database);

		if($con) {
		} else {
			
			die ("Connection Failure");
		}
?>