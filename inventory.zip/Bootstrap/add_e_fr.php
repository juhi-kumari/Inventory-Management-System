<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/nik.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">
    <script src="js/respond.js"></script> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.5.custom.min.js"></script>
</head>

<body>
	<header>
		<nav class = "row">
			<div class = "container">
			<div class= "col-lg-4 col-md-4 col-sm-4 col-xs-4">
				<h1>Inventory Solutions</h1>
			</div> 
			<div class= "col-lg-offset-1 col-lg-7 col-md-offset-0 col-md-8 col-sm-offset-0 col-sm-8  col-xs-offset-3 col-xs-5">
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Products</a></li>
					<li><a href="#">Vendors</a></li>
					<li><a href="#">Contact Us</a></li>
					<li><a href="#">Login</a></li>
				</ul>
			</div>
			</div> 
		</nav>
		<section class= "adv-content col-lg-12 col-xs-12">
			<div class = "container">
			<ul class="breadcrumb">
				<li class="active"><a href="index.html">HOME</a></li>
			</ul>
		</div>
		</section>
	</header>
	<section id="content">
		  </div>
			 <div class="middle">
			    <div class="container">
			      <div class="wrapper row">
			        <div class="col-lg-3 col-md-3 col-sm-4">
						<?php include('include/leftmenu.php');?>
			        </div>
			        <div class="col-lg-9 col-md-9 col-sm-8">
							<ul class="nav nav-tabs">
							  <li role="presentation"><a href="add_e_ac.php">AC</a></li>
							  <li role="presentation"  class="active" ><a href="add_e_fr.php">REFRIGERATOR</a></li>
							  <li role="presentation"><a href="add_e_lp.php">LAPTOP</a></li>
							  <li role="presentation"  ><a href="add_e_tv.php">TV</a></li>
							</ul>
			                <center><h3>Refrigerator</h3></center><br />
				<div class="table-responsive">
					<table class="table table-hover">
						<tr><th>Company</th><th>Model No.</th><th>Edit</th></tr>
						<tr><td>Samsung</td><td>123456</td><td><form action="m_ac.php" method="post" ><input type="hidden" name="type" value="fr"><input type="hidden" name="company" value="samsung"><input  type = "hidden" name="serial" value="FRSA3294"><input class="btn btn-warning" value="Edit" name="submit" type="submit">&nbsp;<input class="btn btn-danger" value="Delete" name="submit" type="submit"></form></td></tr>
						<tr><td>Samsung</td><td>123456</td><td><form action="m_ac.php" method="post" ><input type="hidden" name="type" value="fr"><input type="hidden" name="company" value="samsung"><input  type = "hidden" name="serial" value="FRSA3294"><input class="btn btn-warning" value="Edit" name="submit" type="submit">&nbsp;<input class="btn btn-danger" value="Delete" name="submit" type="submit"></form></td></tr>
						<tr><td>Samsung</td><td>123456</td><td><form action="m_ac.php" method="post" ><input type="hidden" name="type" value="fr"><input type="hidden" name="company" value="samsung"><input  type = "hidden" name="serial" value="FRSA3294"><input class="btn btn-warning" value="Edit" name="submit" type="submit">&nbsp;<input class="btn btn-danger" value="Delete" name="submit" type="submit"></form></td></tr>
					</table>
				</div>
			        </div>
			      </div>
			    </div>
			  </div>
			  
	<?php include('include/bottom.php');?>


<script type="text/javascript">
$(document).ready(function () {
    $('.pics').cycle({
        fx: 'toss',
        next: '#next',
        prev: '#prev'
    });
    $('#datepicker').datepicker({
        inline: true
    });
});
</script>

</body>
</html>
