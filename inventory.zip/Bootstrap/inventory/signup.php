<?php
	
	include ('include/connect.php');
	$table1 = "verification";
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$name = $_POST['name'];
		$user = $_POST['user'];
		$email = $_POST['email'];
		$pass = $_POST['pass'];
		$c_pass = $_POST['conf_pass'];
		$id = "";
		$type = $_POST['type'];
		//input if username is not same as given
		//assign customer_id
		
		if($c_pass == $pass){
			
			$mysqli_q = "SELECT count(id) FROM " . $table1 . " where username = '$user'"; 
			//echo $mysqli_q;
			$result2 = mysqli_query($con, $mysqli_q);// or die ("Connection Failure");
			$row = mysqli_fetch_row($result2);
			if($row[0] != 0){
				header("Location:sign.php?var=1");
				echo "username not available";
			}else{
				if($type == 'customer'){
					$table = 'customer';
					$type = "customer";
					$query = "INSERT INTO {$table} (Cust_name, Email_id) VALUES ('{$name}', '{$email}')";
				}elseif($type == 'dealer'){
					$table = 'dealer';
					$type = 'dealer';
					$query = "INSERT INTO {$table} (Dealer_name, Email_id) VALUES ('{$name}', '$email')";
				}else{ 
					header('Location:sign.php');
				}
				echo $query."<br>";
				$result1 = mysqli_query($con, $query) or die ("Connection Failure");
				$f = mysqli_insert_id($con);
				echo $f;
				
				$query = "INSERT INTO {$table1} (username, password, id, type) VALUES ('$user', '$pass', $f, '$type')";
				//echo $query."<br>";
				
//				or die ("Connection Failed");
				$result = mysqli_query($con, $query);
				if($result == TRUE){
					echo "keep on"; 
					header('Location: login.php?var=1');
					//header('Location: http://www.example.com/');
				}else {
					header('Location : sign.php');
				}
				
			}
		}
	}
	
?>
