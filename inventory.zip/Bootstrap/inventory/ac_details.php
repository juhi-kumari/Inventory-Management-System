<?php
	$message = "";
	if($_SERVER["REQUEST_METHOD"] == "GET"){
		if(isset($_GET["var"])){
			if($_GET['var'] == 1){
				$message = "Username not available.Please insert other username";
			}
		}
	}
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/nik.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">

    <style>
    	.container {
    		
    	}
    	.contain {
    		background-color:white;
    		width:75%;
    		padding-left: 100px;
    		padding-right: 100px;
			padding-bottom: 10px;
			margin-top: 40px;
			margin-bottom: 40px;
    		border:solid black 1px;
    		border-radius:50px;
    	}
    	body {
    		background-color:black;
    	}
    </style>


    <script src="js/respond.js"></script> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.5.custom.min.js"></script>
	
</head>

<body>
	<header>
		<nav class = "row">

			<div class = "container">
			<div class= "col-lg-4 col-md-4 col-sm-4 col-xs-4">
				<h1>Inventory Solutions</h1>
			</div> 
			<div class= "col-lg-offset-1 col-lg-7 col-md-offset-0 col-md-8 col-sm-offset-0 col-sm-8  col-xs-offset-3 col-xs-5">
				<?php include('include/tanu_header.php');?>
			</div>
			</div> 
		</nav>
		<section class= "adv-content col-lg-12 col-xs-12">
			<div class = "container">
			<ul class="breadcrumb">
				<li class="active"><a href="index.html">HOME</a></li><br/>
				<?php echo $message; ?>
			</ul>
			
		</div>
		</section>
	</header>
	<section id="content">

		<div class="container contain">		
			<br />
			<form action="signup.php" method="post">
			<!-- <div class="form-group">  -->
				<h2 align = "center">Product Name AC</h2>
				<br />
				<form class="form-horizontal">
				  <div class="form-group">
					<label for="name" class="col-sm-2 control-label">Type</label>
					<div class="col-sm-9">
					  <input name="name" type="text"  class="form-control" id="name" placeholder="Name">
					</div>
				  </div><br>
				  <div class="form-group">
					<label for="email" class="col-sm-2 control-label">Star Rating</label>
					<div class="col-sm-9">
					  <input name="email" type="email" class="form-control" id="email" placeholder="Email">
					</div>
				  </div><br>
				  <div class="form-group">
					<label for="username" class="col-sm-2 control-label">Capacity</label>
					<div class="col-sm-9">
					  <input name="user" type="text" class="form-control" id="username" placeholder="Username">
					</div>
					<div class="col-sm-1 glyphicon glyphicon-ok" ></div>
					<div class="col-sm-1 glyphicon glyphicon-remove"></div>
				  </div>
				  <div class="form-group">
					<label for="inputPassword3" class="col-sm-2 control-label">Colour</label>
					<div class="col-sm-9">
					  <input name ="pass" type="password" class="form-control" id="inputPassword3" placeholder="Password">
					</div>
				  </div>
				  <div class="form-group">
					<label for="cpass" class="col-sm-2 control-label">Warranty</label>
					<div class="col-sm-9">
					  <input name="conf_pass" type="password" class="form-control" id="cpass" placeholder="Confirm Password">
					</div>
					
					<div class="col-sm-1 glyphicon glyphicon-ok" ></div>
					<div class="col-sm-1 glyphicon glyphicon-remove"></div>
				  </div>
				  <div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
					  <div class="radio">
						  <label>
							<input type="radio" name="type" id="optionsRadios1" value="customer">
							I am Customer
						  </label>
						  <br>
						  <label>
							<input type="radio" name="type" id="optionsRadios1" value="dealer">
							I am Vendor
						  </label>
					  </div>
					</div>
				  </div>				
				  <div class="form-group">
					<div class="col-sm-12">
					  <center><input class="btn btn-primary btn-lg" type="submit" value="&nbsp;&nbsp;Sign Up&nbsp;&nbsp;" name="submit"></center>
					</div>
				  </div>
				<br>
			</form>
			
	</section>

	<footer>
  <div class="footerlink">
  	 <div class="container">
    <p class="lf">Copyright &copy;  <a href="#"></a> - All Rights Reserved</p>
    <div style="clear:both;"></div>
</div>
  </div>
</footer>


<script type="text/javascript">
$(document).ready(function () {
    $('.pics').cycle({
        fx: 'toss',
        next: '#next',
        prev: '#prev'
    });
    $('#datepicker').datepicker({
        inline: true
    });
});
</script>

</body>
</html>
