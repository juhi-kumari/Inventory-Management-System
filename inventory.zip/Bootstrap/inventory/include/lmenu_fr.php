<?php  
					echo '
					<ul class="heading">
			            <li><a href="#">REFRIGERATOR</a></li>
					  </ul>
					  <ul  class="categories">
					    <li><a href="#">Whirlpool</a></li>
					    <li><a href="#">Panasonic</a></li>
						<li><a href="#">Kelvinator</a></li>
			          </ul>';
					?>