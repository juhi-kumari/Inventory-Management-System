			        <?php  
					echo '
					<ul class="heading">
			            <li><a href="#">INVENTORY</a></li>
					  </ul>
					  <ul  class="categories">
					    <li><a href="customer_ac.php?i=-1&var=1">Order items</a></li>
					    <li><a href="#">View Invoice</a></li>
						<li><a href="order_list.php">Order History</a></li>
						
			          </ul>
			          <ul class="heading">
			            <li><a href="#">PERSONAL</a></li>
					  </ul>
					  <ul  class="categories">
					    <li><a href="cust_pers_details.php">Edit Details</a></li>
					    <li><a href="cust_pwd_change.php">Change Password</a></li>
			          </ul>';
					  ?>
