<?php  
					echo '
					<ul class="heading">
			            <li><a href="#">TELEVISION</a></li>
					  </ul>
					  <ul  class="categories">
					    <li><a href="#">LG</a></li>
					    <li><a href="#">Panasonic</a></li>
						<li><a href="#">Sony</a></li>
			          </ul>';
					?>