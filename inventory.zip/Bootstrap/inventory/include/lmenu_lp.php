<?php  
					echo '
					<ul class="heading">
			            <li><a href="#">Laptops</a></li>
					  </ul>
					  <ul  class="categories">
					    <li><a href="#">Apple</a></li>
			            <li><a href="#">Dell</a></li>
			            <li><a href="#">Sony Vaio</a></li>
			          </ul>';
					?>