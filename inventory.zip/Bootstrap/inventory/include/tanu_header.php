<?php
				echo'<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="customer.php">Products</a></li>
					<li><a href="sign.php">Sign Up</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="contact.php">Contact Us</a></li>
				</ul>';
		?>