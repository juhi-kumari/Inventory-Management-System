			        <?php  
					echo '
					<ul class="heading">
			            <li><a href="#">Air conditioner</a></li>
					  </ul>
					  <ul  class="categories">
			            <li><a href="#">Voltas</a></li>
			            <li><a href="#">LG</a></li>
			            <li><a href="#">Blue Star</a></li>
					  </ul>';
			          
					  ?>
