<?php
	include ('include/connect.php');
	if ($_SERVER['REQUEST_METHOD'] == "POST") {
		$cust_id = $_POST['cust'];
		//$research_interest = $_POST['ri'];
		$add = $_POST['add'];
		$serial = array();
		$serial = $_POST['serial'];
		//print_r($serial);
		$quantity = $_POST['quantity'];
		$type = array();
		$count = count($serial);
		$type = $_POST['type'];
		$mrp = array();
		$total = 0;
		$discount = array();
		$stock = array();
		for($i = 0; $i < $count; $i++){
			$query = "SELECT mrp, discount FROM {$type[$i]} WHERE serial_code='".$serial[$i]."'";
			//echo $query;
			$result = mysqli_query($con, $query) or die ("Connection Failure");
			$row = mysqli_fetch_row($result);
			$mrp[$i] = $row[0];
			$discount[$i] = $row[1];
			echo $mrp[$i]."<br/>";
			$total = $total + $mrp[$i];
			//print_r($row);
		}
		echo $total;
		$date = date("Y-m-d");
		echo $date."<br/>";
		$d_date = date('Y-m-d', strtotime("+10 days"));
		echo $d_date."<br/>";
		$cost = array();
		
		//check availability in stock
		for($i = 0; $i < $count; $i++){
			$query = "SELECT quantity FROM inventory_item WHERE serial_code = '$serial[$i]'";
			echo $query."<br/>";
			$result = mysqli_query($con, $query);
			$row = mysqli_fetch_row($result); 
			$stock[$i] = $row[0];
			if($stock[$i] <= $quantity[$i]){
				echo $stock[$i]."unavailable ". $serial[$i]."<br/>";
			}
		}
		
		$query = "INSERT INTO `inventory`.`order` (`Order_id`, `Date`, `Delivery_date`, `Delivery_address`, `Total_bill`, `cust_id`) VALUES (NULL, '$date', '$d_date', '$add', '$total', '$cust_id');";
		echo $query;
		$result = mysqli_query($con, $query) or die ("Connection Failure");
		$order_id = mysqli_insert_id($con);
		if($result == TRUE){
			for($i = 0; $i < $count; $i++){
				$cost[$i] = $mrp[$i] * (1-($discount[$i]/100));
				//echo $cost[$i];
				
				$query1= "INSERT INTO `inventory`.`order_description` (`Order_id`, `serial_code`, `Quantity`, `Discount`, `MRP`, `Cost`) VALUES ('$order_id', '$serial[$i]', '$quantity[$i]', '$discount[$i]', '$mrp[$i]', '$cost[$i]');";
				$result1 = mysqli_query($con, $query1) or die("failure");
				//echo $query1."<br/>";
				if($result1 == 	TRUE){
				
					echo "done <br/>";
					//availbility of product according to serial code and to be inserted 
					$query2 = "SELECT product_id FROM item_tracker WHERE availability=1 AND serial_code ='$serial[$i]'";
					echo $query2;
					$result2 = mysqli_query($con, $query2);
					$j = 0;
					while($row2 = mysqli_fetch_row($result2)){
						$product_id = $row2[0];
						echo "<br/>".$row2[0]." ".$quantity[$i];
						if($j == $quantity[$i]){
							break;
						}
						
						$j++;
						//insert in order_item
						$query_p = "INSERT INTO `inventory`.`order_items` (`Order_id`, `Product_id`, `Serial_code`) VALUES ('$order_id', '$product_id', '$serial[$i]');";
						$result_p = mysqli_query($con, $query_p) or die('3am');
						
						//update in item_tracker
						$query_p = "UPDATE `inventory`.`item_tracker` SET `Availability` = '0' WHERE `item_tracker`.`Product_id` = '$product_id';";
						$result_p = mysqli_query($con, $query_p) or die("undone");
						
						//update in inventory_item
						$stock[$i] = $stock[$i] - 1;
						$query_p = "UPDATE `inventory`.`inventory_item` SET `quantity` = '$stock[$i]' WHERE `inventory_item`.`serial_code` = '$serial[$i]';";
						$result_p = mysqli_query($con, $query_p) or die("just");
						
					}
				}
			}
		}
		//echo date("Y-m-d")."<br/>";
		//echo date('Y-m-d', strtotime("+30 days"));
	}
?>