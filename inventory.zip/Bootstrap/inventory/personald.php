<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/nik.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">
    <script src="js/respond.js"></script> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.5.custom.min.js"></script>
</head>

<body>
	<header>
		<nav class = "row">
			<div class = "container">
			<div class= "col-lg-4 col-md-4 col-sm-4 col-xs-4">
				<h1>Inventory Solutions</h1>
			</div> 
			<div class= "col-lg-offset-1 col-lg-7 col-md-offset-0 col-md-8 col-sm-offset-0 col-sm-8  col-xs-offset-3 col-xs-5">
				<?php include('include/tanu_header.php');?>
			</div>
			</div> 
		</nav>
		<section class= "adv-content col-lg-12 col-xs-12">
			<div class = "container">
			<ul class="breadcrumb">
				<li class="active"><a href="index.html">HOME</a></li>
			</ul>
		</div>
		</section>
	</header>
	<section id="content">
		  </div>
			 <div class="middle">
			    <div class="container">
			      <div class="wrapper row">
			        <div class="col-lg-3 col-md-3 col-sm-4">
						<?php include('include/leftmenu-d.php');?>
			        </div>
			        <div class="col-lg-9 col-md-9 col-sm-8">
						<form action="" method="post">
						<!-- <div class="form-group">  -->
							<h2 align = "center">Personal Details</h2>
							<br />
							<form class="form-horizontal">
							  <div class="form-group">
								<label for="name" class="col-sm-2 control-label">Name</label>
								<div class="col-sm-9">
								  <input name="name" type="text"  class="form-control" id="name" placeholder="Name">
								</div>
							  </div><br>
							  <div class="form-group">
								<label for="email" class="col-sm-2 control-label">Email</label>
								<div class="col-sm-9">
								  <input name="email" type="email" class="form-control" id="email" placeholder="Email">
								</div>
							  </div><br>
							  <div class="form-group">
								<label for="contact" class="col-sm-2 control-label">Contact</label>
								<div class="col-sm-9">
								  <input name="contact" type="text" class="form-control" id="contact" placeholder="Contact">
								</div>
							  </div><br>
							  <div class="form-group">
								<label for="address" class="col-sm-2 control-label">Address</label>
								<div class="col-sm-9">
								  <input name="address" type="text" class="form-control" id="address" placeholder="Line 1">
								</div>
							  </div><br>
							  <div class="form-group">
								<label for="state" class="col-sm-2 control-label">State</label>
								<div class="col-sm-9">
								  <input name ="state" type="text" class="form-control" id="state" placeholder="State">
								</div>
							  </div><br>
							  <div class="form-group">
								<label for="city" class="col-sm-2 control-label">City</label>
								<div class="col-sm-9">
								  <input name = "city" type="text" class="form-control" id="city" placeholder="City">
								</div>
							  </div>
							  <div class="form-group">
								<label for="pincode" class="col-sm-2 control-label">Pincode</label>
								<div class="col-sm-9">
								  <input name="pincode" type="text" class="form-control" id="pincode" placeholder="Pincode">
								</div>
							  </div>
							  <div class="form-group">
								<div class="col-sm-12">
								  <center><input class="btn btn-primary btn-lg" type="submit" value="&nbsp;&nbsp;Edit&nbsp;&nbsp;" name="submit"></center>
								</div>
							  </div>
							<br>
						</form>
			        </div>
			      </div>
			    </div>
			  </div>
			  
	<?php include('include/bottom.php');?>


<script type="text/javascript">
$(document).ready(function () {
    $('.pics').cycle({
        fx: 'toss',
        next: '#next',
        prev: '#prev'
    });
    $('#datepicker').datepicker({
        inline: true
    });
});
</script>

</body>
</html>
