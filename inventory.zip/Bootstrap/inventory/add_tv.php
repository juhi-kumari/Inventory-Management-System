<?php
	include ('include/connect.php');
	$message ="";
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$company = $_POST['company'];
		$model = $_POST['model'];
		$min = $_POST['min'];
		$max = $_POST['max'];
		$quantity = $_POST['quantity'];
		$location = $_POST['location'];
		$serial = "tv_";
		$serial .= $company;
		$serial .= "_";
		$serial .= $model;
		$type = "tv";
		$query1 = "INSERT INTO inventory_item (serial_code, type, company, model_no, min, max, quantity) VALUES ('$serial', '$type', '$company', '$model', $min, $max, $quantity)";
		$result1 = mysqli_query($con, $query1);
		$query2 = "INSERT INTO inventory_location (serial_code, location) VALUES('$serial', '$location')";
		//$query2
		$result2 = mysqli_query($con, $query2);
		if($result2 == TRUE){
			//die("query1");
			$message = "Added Successfully";
		}else{
			//die("query1");
			$message = "Try again later";
		}
	
		//$serial = "hvne";
		$name = $_POST['name'];
		$screen = $_POST['screen'];
		$display = $_POST['display'];
		$hd = $_POST['hd'];
		$resolution = $_POST['resolution'];
		$usb =$_POST['usb'];
		
		$mrp = $_POST['mrp'];
		$discount = $_POST['discount'];
		$query = "INSERT INTO television (Serial_code, Name, Screen_size, Display_type, HDTechnology, Resolution, USB, MRP, Discount) VALUES('$serial', '$name', '$screen', '$display', '$hd', '$resolution', '$usb', $mrp, $discount)";
		//echo $query;
		$result = mysqli_query($con, $query);// or die('try');
		if($result == TRUE){
			$message = "Added Successfully";
		}else{
			$message = "Try again later";
		}
	}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/nik.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">
    <script src="js/respond.js"></script> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.5.custom.min.js"></script>
</head>

<body>
	<header>
		<nav class = "row">
			<div class = "container">
			<div class= "col-lg-4 col-md-4 col-sm-4 col-xs-4">
				<h1>Inventory Solutions</h1>
			</div> 
			<div class= "col-lg-offset-1 col-lg-7 col-md-offset-0 col-md-8 col-sm-offset-0 col-sm-8  col-xs-offset-3 col-xs-5">
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Products</a></li>
					<li><a href="#">Vendors</a></li>
					<li><a href="#">Contact Us</a></li>
					<li><a href="#">Login</a></li>
				</ul>
			</div>
			</div> 
		</nav>
		<section class= "adv-content col-lg-12 col-xs-12">
			<div class = "container">
			<ul class="breadcrumb">
				<li class="active"><a href="index.html">HOME</a></li><br/><?php echo $message; ?>
			</ul>
		</div>
		</section>
	</header>
	<section id="content">
		  </div>
			 <div class="middle">
			    <div class="container">
			      <div class="wrapper row">
			        <div class="col-lg-3 col-md-3 col-sm-4">
					<?php include('include/leftmenu.php');?>
			        </div>
			        <div class="col-lg-9 col-md-9 col-sm-8">
							<ul class="nav nav-tabs">
							  <li role="presentation" ><a href="add_e_ac.php?var=1">AC</a></li>
							  <li role="presentation" ><a href="add_e_ac.php?var=3">REFRIGERATOR</a></li>
							  <li role="presentation"><a href="add_e_ac.php?var=2">LAPTOP</a></li>
							  <li role="presentation" class="active"><a href="add_e_ac.php?var=4">TV</a></li>
							</ul>
			                <center><h3>Television</h3></center>
							<form action="" method="post">			  		
							  <div class="form-group">
								<label for="nam" class="col-sm-2 control-label">Company</label>
								<div class="col-sm-9">
								  <input name="company" type="text" class="form-control" id="nam" placeholder="Company">
								</div>
							  </div>
							  <div class="form-group">
								<label for="na" class="col-sm-2 control-label">Model No.</label>
								<div class="col-sm-9">
								  <input name="model" type="text" class="form-control" id="na" placeholder="Model No.">
								</div>
							  </div>
							  <div class="form-group">
								<label for="name" class="col-sm-2 control-label">Name</label>
								<div class="col-sm-9">
								  <input name="name" type="text" class="form-control" id="name" placeholder="Name">
								</div>
							  </div>
							  <div class="form-group">
								<label for="type" class="col-sm-2 control-label">Screen Size</label>
								<div class="col-sm-9">
								  <input name="screen" type="text" class="form-control" id="type" placeholder="Type">
								</div>
							  </div>
							  <div class="form-group">
								<label for="star" class="col-sm-2 control-label">USB</label>
								<div class="col-sm-9">
								  <select class="form-control" name="usb">
								  <option name="usb" value=></option>
								  <option name="usb" value=1>1</option>
								  <option name="usb" value=2>2</option>
								  <option name="usb" value=3>3</option>
								  <option name="usb" value=4>4</option>
								  <option name="usb" value=5>5</option>
								</select>
								</div>
							  </div>
							  <div class="form-group">
								<label for="name" class="col-sm-2 control-label">Display Type</label>
								<div class="col-sm-9">
								  <input name="display" type="text" class="form-control" id="username" placeholder="Display Type">
								</div>
							  </div>
							  <div class="form-group">
								<label for="name" class="col-sm-2 control-label">Hd Technology</label>
								<div class="col-sm-9">
								  <input name="hd" type="text" class="form-control" id="username" placeholder="Hd Technology">
								</div>
							  </div>
							  <div class="form-group">
								<label for="warranty" class="col-sm-2 control-label">Resolution</label>
								<div class="col-sm-9">
								  <input name="resolution" type="text" class="form-control" id="warranty" placeholder="Resolution">
								</div>
							  </div>
							  <div class="form-group">
								<label for="mrp" class="col-sm-2 control-label">MRP</label>
								<div class="col-sm-9">
								  <input name="mrp" type="text" class="form-control" id="mrp" placeholder="MRP">
								</div>
							  </div>
							  <div class="form-group">
								<label for="discount" class="col-sm-2 control-label">Discount</label>
								<div class="col-sm-9">
								  <input name="discount" type="discount" class="form-control" id="discount" placeholder="Discount">
								</div>
							  </div>
							  <div class="form-group">
								<label for="name" class="col-sm-2 control-label">Location</label>
								<div class="col-sm-9">
								  <input name="location" type="text" class="form-control" id="name" placeholder="Location in Inventory">
								</div>
							</div>
							<div class="form-group">
								<label for="name" class="col-sm-2 control-label">Minimum</label>
								<div class="col-sm-9">
								  <input name="min" type="text" class="form-control" id="name" placeholder="Minimum number in Inventory">
								</div>
							</div>
							<div class="form-group">
								<label for="name" class="col-sm-2 control-label">Maximum</label>
								<div class="col-sm-9">
								  <input name="max" type="text" class="form-control" id="name" placeholder="Maximum number in Inventory">
								</div>
							</div>
							<div class="form-group">
								<label for="nn" class="col-sm-2 control-label">Quantity</label>
								<div class="col-sm-9">
								  <input name="quantity" type="text" class="form-control" id="nn" placeholder="Quantity">
								</div>
							</div>
								<div class="col-sm-12">
								  <center><input class="btn btn-primary btn-lg" type="submit" value="&nbsp;&nbsp;Add&nbsp;&nbsp;" name="submit"></center>
								</div>
							</form>
			        </div>
			      </div>
			    </div>
			  </div>
			    <div class="bottom">
			    <div class="container">
			      <div class="wrapper row">
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Database</h3>
			          <ul class="list1">
			            <li><a href="#">Real Application Clusters</a></li>
			            <li><a href="#">Database Security</a></li>
			            <li><a href="#">Secure Enterprise Search</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Quick Links</h3>
			          <ul class="list2">
			            <li><a href="#">Vendors</a></li>
			            <li><a href="#">Login</a></li>
			            <li><a href="#"></a></li>
			            <li><a href="#">For Midsize Companies</a></li>
			            <li><a href="#">Investors</a></li>
			            <li><a href="#">Technology Network</a></li>
			            <li><a href="#">FAQs</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Top Selling</h3>
			          <ul class="list2">
			            <li><a href="#">Enterprise Architecture</a></li>
			            <li><a href="#">Enterprise 2.0</a></li>
			            <li><a href="#">Grid</a></li>
			            <li><a href="#">Service-Oriented Architecture</a></li>
			            <li><a href="#">Virtualization</a></li>
			            <li><a href="#">Database XE</a></li>
			            <li><a href="#">Enterprise Management</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <div id="datepicker"></div>
			        </div>
			      </div>
			    </div>
			  </div>

	</section>

	<footer>
  <div class="footerlink">
  	 <div class="container">
    <p class="lf">Copyright &copy;  <a href="#"></a> - All Rights Reserved</p>
    <div style="clear:both;"></div>
</div>
  </div>
</footer>


<script type="text/javascript">
$(document).ready(function () {
    $('.pics').cycle({
        fx: 'toss',
        next: '#next',
        prev: '#prev'
    });
    $('#datepicker').datepicker({
        inline: true
    });
});
</script>

</body>
</html>
