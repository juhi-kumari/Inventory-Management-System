<?php
	$message = "";
	$serial = "AC LS19A5LN";
	include ('include/connect.php');
	//if($_SERVER["REQUEST_METHOD"] == "GET"){
		$query = "SELECT * FROM refrigerator WHERE serial_code='$serial'";
		$result = mysqli_query($con, $query);
		$row = mysqli_fetch_row($result);
		//print_r($row);
		$query = "SELECT * FROM inventory_item WHERE serial_code='$serial'";
		$result = mysqli_query($con, $query);
		$row1 = mysqli_fetch_row($result);
		//print_r($row1);
	//}
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/nik.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">

    <style>
    	.container {
    		
    	}
    	.contain {
    		background-color:white;
    		width:75%;
    		padding-left: 100px;
    		padding-right: 100px;
			padding-bottom: 10px;
			margin-top: 40px;
			margin-bottom: 40px;
    		border:solid black 1px;
    		border-radius:50px;
    	}
    	body {
    		background-color:black;
    	}
    </style>


    <script src="js/respond.js"></script> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.5.custom.min.js"></script>
	
</head>

<body>
	<header>
		<nav class = "row">

			<div class = "container">
			<div class= "col-lg-4 col-md-4 col-sm-4 col-xs-4">
				<h1>Inventory Solutions</h1>
			</div> 
			<div class= "col-lg-offset-1 col-lg-7 col-md-offset-0 col-md-8 col-sm-offset-0 col-sm-8  col-xs-offset-3 col-xs-5">
				<?php include('include/tanu_header.php');?>
			</div>
			</div> 
		</nav>
		<section class= "adv-content col-lg-12 col-xs-12">
			<div class = "container">
			<ul class="breadcrumb">
				<li class="active"><a href="index.html">HOME</a></li><br/>
				<?php echo $message; ?>
			</ul>
			
		</div>
		</section>
	</header>
	<section id="content">
		<div class="container contain">		
			<br />
			<!--<form action="signup.php" method="post">
			<div class="form-group">  -->
				<h2 align = "center"><?php echo $row[0];?></h2>
				<br />
				<form class="form-horizontal">
					<div class="form-group">
					<label for="email" class="col-sm-2 control-label">MRP</label>
					<div class="col-sm-9">
					  <?php echo $row[7];?>
					</div>
				  </div>
				  <div class="form-group">
					<label for="email" class="col-sm-2 control-label">Discount</label>
					<div class="col-sm-9">
					  <?php echo $row[8];?>
					</div>
				  </div>
				  <div class="form-group">
					<label for="email" class="col-sm-2 control-label">Company</label>
					<div class="col-sm-9">
					  <?php echo $row1[2];?>
					</div>
					</div>
				  <div class="form-group">
					<label for="name" class="col-sm-2 control-label">Model_Number</label>
					<div class="col-sm-9">
					  <?php echo $row1[3];?>
					</div>
					</div>
					<div class="form-group">
					<label for="name" class="col-sm-2 control-label">Star Rating</label>
					<div class="col-sm-9">
					  <?php echo $row[2];?>
					</div>
				  </div>
				  <div class="form-group">
					<label for="email" class="col-sm-2 control-label">Capacity</label>
					<div class="col-sm-9">
					  <?php echo $row[3];?>
					</div>
				  </div>
				  <div class="form-group">
					<label for="username" class="col-sm-2 control-label">Colour</label>
					<div class="col-sm-9">
						<?php echo $row[4];?>
					</div>
				  </div>
				  <div class="form-group">
					<label for="inputPassword3" class="col-sm-2 control-label">Net Height</label>
					<div class="col-sm-9">
					  <?php echo $row[5];?>
					</div>
				  </div>
				  <div class="form-group">
					<label for="cpass" class="col-sm-2 control-label">Warranty</label>
					<div class="col-sm-9"> 
						<?php echo $row[6];?>
					</div>
				  </div>
				  				
				  <div class="form-group">
					<div class="col-sm-4">
					  <center><input class="btn btn-primary btn-lg" type="submit" value="&nbsp;&nbsp;Continue Shopping&nbsp;&nbsp;" name="submit"></center>
					</div>
					<div class="col-sm-4">
					  <center><input class="btn btn-primary btn-lg" type="submit" value="&nbsp;&nbsp;Add to cart&nbsp;&nbsp;" name="submit"></center>
					</div>
					<div class="col-sm-4">
					  <center><input class="btn btn-primary btn-lg" type="submit" value="&nbsp;&nbsp;Proceed for payment&nbsp;&nbsp;" name="submit"></center>
					</div>
				  </div>
				<br>
			</form>
			
	</section>

	<footer>
  <div class="footerlink">
  	 <div class="container">
    <p class="lf">Copyright &copy;  <a href="#"></a> - All Rights Reserved</p>
    <div style="clear:both;"></div>
</div>
  </div>
</footer>


<script type="text/javascript">
$(document).ready(function () {
    $('.pics').cycle({
        fx: 'toss',
        next: '#next',
        prev: '#prev'
    });
    $('#datepicker').datepicker({
        inline: true
    });
});
</script>

</body>
</html>
