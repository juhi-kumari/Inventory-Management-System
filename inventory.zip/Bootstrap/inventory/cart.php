<?php
include ('include/session.php');
include ('include/connect.php');
include ('include/session_check.php');
	$message = "";
	if($_SERVER["REQUEST_METHOD"] == "GET"){
		$t = $_GET["i"];
		
	}
	$type = "air_conditioner";
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/nik.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">

    <style>
    	.container {
    		
    	}
    	.contain {
    		background-color:white;
    		width:75%;
    		padding-left: 100px;
    		padding-right: 100px;
			padding-bottom: 10px;
			margin-top: 40px;
			margin-bottom: 40px;
    		border:solid black 1px;
    		border-radius:50px;
    	}
    	body {
    		background-color:black;
    	}
    </style>


    <script src="js/respond.js"></script> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.5.custom.min.js"></script>
	
</head>

<body>
	<header>
		<nav class = "row">

			<div class = "container">
			<div class= "col-lg-4 col-md-4 col-sm-4 col-xs-4">
				<h1>Inventory Solutions</h1>
			</div> 
			<div class= "col-lg-offset-1 col-lg-7 col-md-offset-0 col-md-8 col-sm-offset-0 col-sm-8  col-xs-offset-3 col-xs-5">
				<?php include('include/tanu_header.php');?>
			</div>
			</div> 
		</nav>
		<section class= "adv-content col-lg-12 col-xs-12">
			<div class = "container">
			<ul class="breadcrumb">
				<li class="active"><a href="index.html">HOME</a></li><br/>
				<?php echo $message; ?>
			</ul>
			
		</div>
		</section>
	</header>
	<section id="content">

		<div class="container contain">		
			<br />
			<form action="cust_invoice.php" method="post">
			<!-- <div class="form-group">  -->
				<h2 align = "center">!CART!</h2>
				<br />
				
				<?php
				for($k = 0; $k <= $t; $k++) {
					$query = "SELECT name FROM {$type} WHERE serial_code='{$_SESSION['order'][$k]}'";
					$result = mysqli_query($con, $query) or die ("Connection Failure");
					$row = mysqli_fetch_row($result);
					echo '
					<form class="form-horizontal">
					  <div class="form-group">
						<label for="name" class="col-sm-2 control-label">'.$row[0].'</label>
						<div class="col-sm-9">
							<input type="hidden" name="serial[]" value="'.$_SESSION['order'][$k].'">
							<input type="hidden" name="type[]" value="'.$type.'">
							<input type="hidden" name="cust" value="'.$_SESSION['id'].'">
						  <input name="quantity[]" type="text"  class="form-control" id="name" placeholder="Enter Quantity" value ="" >
						</div>
					  </div><br>'
					  ; 
					}  
					  ?>
				  
				  <div class="form-group">
						<label for="address" class="col-sm-2 control-label">Address</label>
						<div class="col-sm-9">
						  <input name="add" type="text" class="form-control" id="email" placeholder="Enter delivery address">
						</div>
					  </div><br>
				  				
				  <div class="form-group">
					<div class="col-sm-12">
					  <center><input class="btn btn-primary btn-lg" type="submit" value="&nbsp;&nbsp;Confirm and Get Bill&nbsp;&nbsp;" name="submit"></center>
					</div>
				  </div>
				<br>
			</form>
			
	</section>

	<footer>
  <div class="footerlink">
  	 <div class="container">
    <p class="lf">Copyright &copy;  <a href="#"></a> - All Rights Reserved</p>
    <div style="clear:both;"></div>
</div>
  </div>
</footer>


<script type="text/javascript">
$(document).ready(function () {
    $('.pics').cycle({
        fx: 'toss',
        next: '#next',
        prev: '#prev'
    });
    $('#datepicker').datepicker({
        inline: true
    });
});
</script>

</body>
</html>
