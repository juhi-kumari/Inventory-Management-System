<?php
	include ('include/connect.php');
	$cust = "abc";
	$serial = array();
	$serial[0] = "AC LS19A5LN";
	$serial[1] = "ACGD12fr5";
	//$serial[2] = "ACON182flt";
	//$serial[3] = "ACSM12JC2U";
	$type = array();
	$type[0] = "air_conditioner";
	$type[1] = "air_conditioner";
	$type[2] = "air_conditioner";
	$type[3] = "air_conditioner";
?>
<html>
<head></head>
<body>
	<form action="order2.php" method="post">
	Address of Delivery <input type="text" name="add"><br>
		<input type="hidden" name="cust" value= "<?php echo $cust; ?>"><br>
		<?php 
			for($i = 0; $i < count($serial); $i++){
				$query = "SELECT name FROM {$type[$i]} WHERE serial_code='{$serial[$i]}'";
				$result = mysqli_query($con, $query) or die ("Connection Failure");
				$row = mysqli_fetch_row($result);
				//print_r($row);
				echo $row[0].'<br/>
				<input type="hidden" name="serial[]" value="'.$serial[$i].'">
				<input type="hidden" name="type[]" value="'.$type[$i].'">
				Quantity <input type="text" name="quantity[]"><br>
				';
			}
		?>
		<input type="submit" value="Submit">
	</form>
</body>
</html>