<!doctype html>
<?php 
include ('include/connect.php');
include ('include/session.php');
include ('include/session_check.php');
	//$serial = array();i=0;
	//$i = 1;
	if($_SERVER["REQUEST_METHOD"] == "GET"){
		//echo $_GET['var'];
		//echo $_GET['i'];
		if(isset($_GET["var"]) && !isset($_GET["serial"]) && isset($_GET["i"]) ){
			$i = $_GET['i'];
			//echo "<h3>1".$i."</h3>";
			$yo = $_GET["var"];
			if($_GET['var'] == 1){
				//ac
				$type = "air_conditioner";
				$s = "ac";	
				//echo "kbvkdfjbkjfbjfbjfbk";
			}else if($_GET['var'] == 2){
				//lp
				$type = "laptop";
				$s = "lp";	
			}else if($_GET['var'] == 3){
				$s = "fr";	
				$type = "refrigerator";
			}else if($_GET['var'] == 4){
				$s = "tv";	
				$type = "television"; 
			}else{
				$type = NULL;
			}
			$query = "SELECT Serial_code, Name, MRP FROM {$type}";
			//echo $query;
			$result = mysqli_query($con, $query) or die ("gadbad");
			
		} else if (isset($_GET["var"]) && isset($_GET["serial"]) && isset($_GET["i"])) {
			$i = $_GET['i'];$i++;
			//echo "<h3>2".$i."</h3>";
			$yo = $_GET["var"];
			$_SESSION["order"][$i] = $_GET["serial"];
			if($_GET['var'] == 1){
				//ac
				$type = "air_conditioner";
				$s = "ac";	
				//echo "kbvkdfjbkjfbjfbjfbk";
			}else if($_GET['var'] == 2){
				//lp
				$type = "laptop";
				$s = "lp";	
			}else if($_GET['var'] == 3){
				$s = "fr";	
				$type = "refrigerator";
			}else if($_GET['var'] == 4){
				$s = "tv";	
				$type = "television"; 
			}else{
				$type = NULL;
			}
			$query = "SELECT Serial_code, Name, MRP FROM {$type}";
			//echo $query;
			$result = mysqli_query($con, $query) or die ("gadbad");
			
		} else {
				//echo "kbvkdfjbkjfbjfbjfbk";
			//echo "<h3>3".$i."</h3>";
			$yo = 1;
			$type = "air_conditioner";	
			$s ="ac";
			$query = "SELECT Serial_code, Name, MRP FROM {$type}";
			echo $query;
			$result = mysqli_query($con, $query) or die ("gadbad");
		}
	}
?>
<html>
<head>
    <meta charset="utf-8">
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/nik.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">
    <script src="js/respond.js"></script> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.5.custom.min.js"></script>
</head>

<body>
	<header>
		<nav class = "row">
			<div class = "container">
			<div class= "col-lg-4 col-md-4 col-sm-4 col-xs-4">
				<h1>Inventory Solutions</h1>
			</div> 
			<div class= "col-lg-offset-1 col-lg-7 col-md-offset-0 col-md-8 col-sm-offset-0 col-sm-8  col-xs-offset-3 col-xs-5">
				<?php include('include/tanu_header1.php');?>

			</div>
			</div> 
		</nav>
		<section class= "adv-content col-lg-12 col-xs-12">
			<div class = "container">
			<ul class="breadcrumb">
				<li><a href="index.html">HOME</a></li>
				<li class="active"><a href="customer_ac.php">A.C.</a></li>
			</ul>
		</div>
		</section>
	</header>
	<section id="content">
			 <div class="middle">
			    <div class="container">
				<div class="col-lg-12 col-md-12 col-sm-12">
				<ul class="nav nav-tabs">
							  <li role="presentation" <?php if ($yo == 1) {echo 'class="active"';}?>><a href="customer_ac.php?var=1&t=<?php echo $i;?>">AC</a></li>
							  <li role="presentation" <?php if ($yo == 3) {echo 'class="active"';}?>><a href="customer_ac.php?var=3&t=<?php echo $i;?>">REFRIGERATOR</a></li>
							  <li role="presentation" <?php if ($yo == 2) {echo 'class="active"';}?>><a href="customer_ac.php?var=2&t=<?php echo $i;?>">LAPTOP</a></li>
							  <li role="presentation" <?php if ($yo == 4) {echo 'class="active"';}?> ><a href="customer_ac.php?var=4&t=<?php echo $i;?>">TV</a></li>
							</ul>
							<br/> <br/>
				</div>
				
			      <div class="wrapper row">
			        <div class="col-lg-3 col-md-3 col-sm-4">
						<?php 
						if ($yo == 1) {
							include('include/lmenu_ac.php');
						} else if ($yo == 2) {
							include('include/lmenu_lp.php');
						} else if($yo == 3) {
							include('include/lmenu_fr.php');
						} else if ($yo == 4) {
							include('include/lmenu_tv.php');
						}
						?>
			        </div>
			        <div class="col-lg-9 col-md-9 col-sm-8">
			                <div class="row carousel-holder">
								<div class="col-md-12">
									<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
										<ol class="carousel-indicators">
											<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
											<li data-target="#carousel-example-generic" data-slide-to="1"></li>
											<li data-target="#carousel-example-generic" data-slide-to="2"></li>
										</ol>
										<div class="carousel-inner">
											<div class="item active">
												<img class="slide-image" src="images/laptops/bck_image.jpg" alt="">
											</div>
											<div class="item">
												<img class="slide-image" src="images/2page-img2.jpg" alt="">
											</div>
											<div class="item">
												<img class="slide-image" src="images/1page-img2.jpg" alt="">
											</div>
										</div>
										<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
											<span class="glyphicon glyphicon-chevron-left"></span>
										</a>
										<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
											<span class="glyphicon glyphicon-chevron-right"></span>
										</a>
									</div>
								</div>
							</div>
							<br/>
							<div class="row">
							<?php $price = 2000; $product = "fdkngjfd"; $serial = "fgfgfg"; 
							
						while($row = mysqli_fetch_row($result)){
							echo '
								<div class="col-sm-4 col-lg-4 col-md-4">
									<div class="thumbnail">
										<img src="http://placehold.it/320x150" alt="">
										<div class="caption">
											<h4 class="pull-right">'.$row[2].'</h4>
											<h4><a href="details_'.$s.'.php?var='. $row[0].'&t='.$i.'">'.$row[0].'</a>
											</h4>
										</div>
										<div class="ratings">
											<p class="pull-right">15 reviews</p>
											<p>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
												<span class="glyphicon glyphicon-star"></span>
											</p>
										</div>
									</div></div>
									';
							}
									?>
								

							</div>
						  </div>
						</div>
					  </div>
					  </div>
			  
	


<footer>
  <div class="footerlink">
  	 <div class="container">
    <p class="lf">Copyright &copy;  <a href="#"></a> - All Rights Reserved</p>
    <div style="clear:both;"></div>
</div>
  </div>
</footer>


<script type="text/javascript">
$(document).ready(function () {
    $('.pics').cycle({
        fx: 'toss',
        next: '#next',
        prev: '#prev'
    });
    $('#datepicker').datepicker({
        inline: true
    });
});
</script>

</body>
</html>
