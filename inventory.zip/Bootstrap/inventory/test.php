<?php
//customer_ac.php?var=1&serial='1235'&i=1
if($_SERVER["REQUEST_METHOD"] == "GET"){
		echo $_GET["var"]."<br/>";
		$c = $_GET["serial"];
		echo $c."<br/>";
		echo $_GET["i"]."<br/>";
		
		if(isset($_GET["var"])){
			$t = $_GET["t"];
			$serial = $_GET["var"];
		}
	}
?>