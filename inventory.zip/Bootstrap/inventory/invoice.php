<?php
	include ('include/connect.php');
	
	$order_id = "";
	if ($_SERVER['REQUEST_METHOD'] == "POST") {
		$order_id = $_POST['order'];
		if($order_id == "" || $order_id == NULL){
			header('Location:order_list.php');
		}
		$type = "";
		$query = "SELECT Order_id, inventory_item.serial_code, company, model_no, order_description.quantity, MRP, discount, cost, type FROM order_description INNER JOIN inventory_item where inventory_item.serial_code = order_description.serial_code AND order_description.Order_id='$order_id' ";
		//echo $query."<br/>";
		$result = mysqli_query($con, $query) or die("probles");
		
		$date = "SELECT `Date` FROM `order` WHERE `Order_id` = $order_id";
		//echo $date;
		$result0 = mysqli_query($con, $date) or die("probles");
		$row0 = mysqli_fetch_row($result0);
		$dat = $row0[0];
	}else{
		header('Location:order_list.php');
	}
	
	//echo $dat;
?>
<!doctype html>
<?php include ('include/session.php');
include ('include/session_check.php');
?>
<html>
<head>
    <meta charset="utf-8">
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/nik.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">
    <script src="js/respond.js"></script> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.5.custom.min.js"></script>
</head>

<body>
	<header>
		<nav class = "row">
			<div class = "container">
			<div class= "col-lg-4 col-md-4 col-sm-4 col-xs-4">
				<h1>Inventory Solutions</h1>
			</div> 
			<div class= "col-lg-offset-1 col-lg-7 col-md-offset-0 col-md-8 col-sm-offset-0 col-sm-8  col-xs-offset-3 col-xs-5">
				<?php include('include/tanu_header1.php');?>
			</div>
			</div> 
		</nav>
		<section class= "adv-content col-lg-12 col-xs-12">
			<div class = "container">
			<ul class="breadcrumb">
				<li class="active"><a href="index.html">HOME</a></li>
			</ul>
		</div>
		</section>
	</header>
	<section id="content">
		  </div>
			 <div class="middle">
			    <div class="container">
			      <div class="wrapper row">
			        <div class="col-lg-3 col-md-3 col-sm-4">
						<?php include('include/cust_menu.php');?>
			        </div>
			        <div class="col-lg-9 col-md-9 col-sm-8">
						<form action="" method="post">
						<!-- <div class="form-group">  -->
							<h2 align = "center">Invoice</h2>
							<h2 align = "center">Order ID : <?php echo $order_id; ?></h2>
							<br />
							<h4 align="left">Date  :   <?php echo $dat; ?><br ></h4>
							
							<div class="table-responsive">
								<table class="table table-hover">
									<tr class="success"><th>S. No.</th><th>Product Name</th><th>Company</th><th>Model No.</th><th>Quantity</th><th>MRP</th><th>Discount</th><th>Subtotal</th></tr>
									<?php
										$i = 1;
										while($row = mysqli_fetch_row($result)){
											//print_r($row);
											//echo "<br/>";
											$serial = $row[1];
											$type = $row[8];
											//echo $type;
											if($type == "ac" || $type == "AC"){
												$type = "air_conditioner";
											}else if($type == "tv" || $type == "TV"){
												$type = "television";
											}else if($type == "lp" || $type == "LP"){
												$type = "laptop";
											}else if($type == "fr" || $type == "FR"){
												$type = "refrigerator";
											}
											$query1 = "SELECT name from $type WHERE serial_code='$serial'";
											//echo "<br/>".$query1;
											//echo "<br/>";
											$result1 = mysqli_query($con, $query1) or die("probles");
											
											$name = mysqli_fetch_row($result1);
											if($name[0] == "" ||$name[0] == NULL){
												$name[0] = $type;
											}
											echo "<tr><td>{$i}</td><td>".$name[0]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td><td>".$row[7]."</td></tr>";
											//echo "Name Company Model No.  Quantity MRP discount Subtotal"; 
											//echo "Name : $row[]"
											$i++;
										}
									?>
								</table>
							</div>
					</div>
			      </div>
			    </div>
			  </div>
			  
	<?php include('include/bottom.php');?>


<script type="text/javascript">
$(document).ready(function () {
    $('.pics').cycle({
        fx: 'toss',
        next: '#next',
        prev: '#prev'
    });
    $('#datepicker').datepicker({
        inline: true
    });
});
</script>

</body>
</html>
