<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Website</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/nik.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui-1.8.5.custom.css" type="text/css" media="all">
    <script src="js/respond.js"></script> 
	<script type="text/javascript" src="js/jquery-1.4.2.min.js" ></script>
	<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.5.custom.min.js"></script>
</head>

<body>
	<header>
		<nav class = "row">
			<div class = "container">
			<div class= "col-lg-4 col-md-4 col-sm-4 col-xs-4">
				<h1>Inventory Solutions</h1>
			</div> 
			<div class= "col-lg-offset-1 col-lg-7 col-md-offset-0 col-md-8 col-sm-offset-0 col-sm-8  col-xs-offset-3 col-xs-5">
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Products</a></li>
					<li><a href="#">Vendors</a></li>
					<li><a href="#">Contact Us</a></li>
					<li><a href="#">Login</a></li>
				</ul>
			</div>
			</div> 
		</nav>
		<section class= "adv-content ">
			<div class = "container">
			<div class="col-lg-11 col-xs-11">
			<ul class="breadcrumb">
				<li><a href="index.html">HOME</a></li>
				<li class="active"><a href="admin.html">ADMIN</a></li>
			</ul>
		</div>
		<div class="col-lg-1">
			<a href="logout.php">LOGOUT</a>
		</div>
		</section>
	</header>
	<section id="content">
		  <div class="top">
		    <div class="container">
		      <div class="clearfix row">
		      	        <div class="col-lg-9 col-md-9 col-sm-8">
					         <h2>Analysis</h2>
							 <p>CHART</p>
					         <div class="img-box">
					         <figure><img src="images/3page-img1.jpg" alt=""></figure>
					         <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit pellentesque sed dolor. Aliquam congue fermentum nisl <a href="#">mauris accumsan nulla veldiam</a> sedlacus utenim adipiscing aliquet venenatis inpede maliquet amet euismod.</p>
					            Nauctor ligul aliquam dapibus tincidunt metus praesent justo dolor lobortis lobort- sissim pulvinar aclorem vestibulum sed ante donec sagittis euismod purus lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie </div>
					          <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit pellentesque dolor aliquam congue fermentum nisl mauris accumsan nulla veldiam sed lacus utenim adipiscing <a href="#">aliquet nulla venenatis inpede</a> maliquet amet euismod nauctor ligula aliquam dapibus tincidunt metus praesent justo dolor lobortis quis lobortisissim pulvinar aclorem vestibulum sed ante. </p>
					          <a href="#" class="more">Read More</a> 
					      </div>
					        <div class="col-lg-3 col-md-3 col-sm-4">
					        <h2>Reports</h2>
					          <ul class="categories">
					            <li><a href="#">Today</a></li>
					            <li><a href="#">Yesterday</a></li>
					            <li><a href="#">Week</a></li>
					            <li><a href="#">Month</a></li>
					            <li><a href="#">6 monthly</a></li>
					            <li><a href="#">Yearly</a></li>
					            <li><a href="#">Yearly</a></li>
					          </ul>
		      </div>
		    </div>
		  </div>
		</div>
			<div class="middle">
			    <div class="container">
			    <div class="wrapper row">
			   	<div class="col-lg-9 col-md-9 col-sm-8">
			       
							<h2 align = "center">Add Item</h2>
							<br />
							<form action="" method="post">			  		
							  <div class="form-group">
								<label for="username" class="col-sm-2 control-label">Username</label>
								<div class="col-sm-9">
								  <input name="username" type="text" class="form-control" id="username" placeholder="Username">
								</div>
								<div class="col-sm-1 glyphicon glyphicon-ok" ></div>
								<div class="col-sm-1 glyphicon glyphicon-remove"></div>
							  </div>
							  <div class="form-group">
								<label for="inputPassword3" class="col-sm-2 control-label">Password</label>
								<div class="col-sm-9">
								  <input name=="pass" type="password" class="form-control" id="inputPassword3" placeholder="Password">
								</div>
							  </div>
								<div class="col-sm-12">
								  <center><input class="btn btn-primary btn-lg" type="submit" value="&nbsp;&nbsp;Login&nbsp;&nbsp;" name="submit"></center>
								</div>
							</form>

			    </div>
			      <div class="col-lg-3 col-md-3 col-sm-4">
			      	<h2>Products</h2>
			          <ul class="categories">
			            <li><a href="#">Add item</a></li>
			            <li><a href="#">See shortages</a></li>
			            <li><a href="#">Top selling</a></li>
			            <li><a href="#">Sales</a></li>
			            <li><a href="#">View Available</a></li>
			            <li><a href="#">View Sold</a></li>
			            <li><a href="#">Modify items</a></li>
			          </ul>			          
			        </div>
			      </div>
			    </div>
			  </div>
			   <div class="top">
		    <div class="container">
		      <div class="clearfix row">
		      	        <div class="col-lg-9 col-md-9 col-sm-8">
					         <h2>Sales</h2>
							 <p>CHART</p>
					         <div class="img-box">
					         <figure><img src="images/3page-img1.jpg" alt=""></figure>
					         <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit pellentesque sed dolor. Aliquam congue fermentum nisl <a href="#">mauris accumsan nulla veldiam</a> sedlacus utenim adipiscing aliquet venenatis inpede maliquet amet euismod.</p>
					            Nauctor ligul aliquam dapibus tincidunt metus praesent justo dolor lobortis lobort- sissim pulvinar aclorem vestibulum sed ante donec sagittis euismod purus lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie </div>
					          <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit pellentesque dolor aliquam congue fermentum nisl mauris accumsan nulla veldiam sed lacus utenim adipiscing <a href="#">aliquet nulla venenatis inpede</a> maliquet amet euismod nauctor ligula aliquam dapibus tincidunt metus praesent justo dolor lobortis quis lobortisissim pulvinar aclorem vestibulum sed ante. </p>
					          <a href="#" class="more">Read More</a> </div>
					        <div class="col-lg-3 col-md-3 col-sm-4">
					        <h2>Vendors</h2>
					          <ul class="categories">
					            <li><a href="#">View All</a></li>
					            <li><a href="#">Current Dealing</a></li>
					            <li><a href="#"></a></li>
					            <li><a href="#">Discounts</a></li>
					            <li><a href="#">Vendors Corner</a></li>
					          </ul>
		      </div>
		    </div>
		  </div>
		</div>

			<div class="middle">
			    <div class="container">
			      <div class="wrapper row">
			      	<div class="col-lg-9 col-md-9 col-sm-8">
					          <h2>Grow service revenue with world-class<br />
					            lifecycle service and support.</h2>
					          <p>Fusce euismod consequat ante. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Pellentesque sed dolor. Aliquam congue fermentum nisl. Mauris accumsan nulla vel diam. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede m aliquet sit amet, euismod in, auctor ut, ligula. Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis, lobortisissim, pulvinar ac, lorem. Vestibulum sed ante. Donec sagittis euismod purus.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Praesent vestibulum molestie lacus. Aenean nonummy hendrerit mauris. Phasellus porta. </p>
					          <p><a href="#" class="more">Read More</a></p>
					          <section class="images">
					            <figure><a href="#"><img src="images/1page-img1.jpg" alt=""></a></figure>
					            <figure><a href="#"><img src="images/1page-img2.jpg" alt=""></a></figure>
					            <figure><a href="#"><img src="images/1page-img3.jpg" alt=""></a></figure>
							  </section>
					</div>
			        <div class="col-lg-3 col-md-3 col-sm-4">
					      	<h2>Details</h2>
					          <ul class="categories">
					            <li><a href="#">Edit Details</a></li>
					            <li><a href="#">Logout</a></li>
					            <li><a href="#">Top selling</a></li>
					          </ul>			          
			        </div>
			      </div>
			    </div>
			  </div>

			    <div class="bottom">
			    <div class="container">
			      <div class="wrapper row">
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Database</h3>
			          <ul class="list1">
			            <li><a href="#">Real Application Clusters</a></li>
			            <li><a href="#">Database Security</a></li>
			            <li><a href="#">Secure Enterprise Search</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Quick Links</h3>
			          <ul class="list2">
			            <li><a href="#">Vendors</a></li>
			            <li><a href="#">Login</a></li>
			            <li><a href="#"></a></li>
			            <li><a href="#">For Midsize Companies</a></li>
			            <li><a href="#">Investors</a></li>
			            <li><a href="#">Technology Network</a></li>
			            <li><a href="#">FAQs</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <h3>Top Selling</h3>
			          <ul class="list2">
			            <li><a href="#">Enterprise Architecture</a></li>
			            <li><a href="#">Enterprise 2.0</a></li>
			            <li><a href="#">Grid</a></li>
			            <li><a href="#">Service-Oriented Architecture</a></li>
			            <li><a href="#">Virtualization</a></li>
			            <li><a href="#">Database XE</a></li>
			            <li><a href="#">Enterprise Management</a></li>
			          </ul>
			        </div>
			        <div class="col-lg-3 col-md-3 col-sm-3">
			          <div id="datepicker"></div>
			        </div>
			      </div>
			    </div>
			  </div>
 
	</section>

	<footer>
  <div class="footerlink">
  	 <div class="container">
    <p class="lf">Copyright &copy;  <a href="#"></a> - All Rights Reserved</p>
    <div style="clear:both;"></div>
</div>
  </div>
</footer>


<script type="text/javascript">
$(document).ready(function () {
    $('.pics').cycle({
        fx: 'toss',
        next: '#next',
        prev: '#prev'
    });
    $('#datepicker').datepicker({
        inline: true
    });
});
</script>

</body>
</html>
